About the Blog

Simple portfolio page with blog post.

Includes the CSS, Images and Html files.
